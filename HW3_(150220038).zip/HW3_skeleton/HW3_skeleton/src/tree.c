#include "tree.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>


// Given a game state, return a tree node
TreeNode *init_node(GameState *gs){
    TreeNode* newNode = (TreeNode*)malloc(sizeof(TreeNode));
    newNode->game_state= gs;
    newNode->num_children=-1; 
    newNode->children=NULL;    

    return newNode;
}

// Given a game state, construct the tree up to the given depth using the available moves for each node
// Returns the root node
// You can assume that depth >= 2
TreeNode *init_tree(GameState *gs, int depth){

    TreeNode* root = init_node(gs); //base case
    GameStatus status = get_game_status(gs);
    if (depth == 1 || status == PLAYER_1_WIN || status == PLAYER_2_WIN || status == DRAW ) {
        return root;  
    }
   
    bool moves[gs->width];
    memset(moves, false, gs->width * sizeof(bool));
    int move_count = available_moves(gs, moves); 

    root->num_children=move_count;
    root->children= (TreeNode**)malloc(move_count*sizeof(TreeNode*));

    int child_index=0;
    for (int i = 0; i < gs->width; i++){
        
        if (moves[i]){            
            GameState* newState = make_move(gs,i);
            root->children[child_index] = init_tree(newState, depth-1);
            child_index++;
        }
    }
       
    return root;
}

// Frees the tree
void free_tree(TreeNode *root){
    if (root==NULL){
        return; //empty
    }
    for(int i=0; i< root->num_children; i++){
        free_tree(root->children[i]); //recursive call
    }

    free(root->children);
    free(root->game_state->board);
    free(root->game_state);
    
    free(root);
}

// Expand all leaf nodes of the tree by one level
void expand_tree(TreeNode *root){
    GameStatus status = get_game_status(root->game_state);

    if (status == PLAYER_1_WIN || status == PLAYER_2_WIN || status == DRAW) {
        //no_expand_for_finished_game
        return; 
    }


    if(root->children==NULL){ //it is leaf
        bool moves[root->game_state->width];
        memset(moves, false, root->game_state->width * sizeof(bool));
        int move_count = available_moves(root->game_state, moves); 

        root->num_children=move_count;
        root->children= (TreeNode**) malloc(move_count*sizeof(TreeNode*));

        int child_index=0;
        for (int i = 0; i < root->game_state->width; i++){
            
            if (moves[i]){            
                GameState* newState = make_move(root->game_state,i);
                root->children[child_index] = init_node(newState);
                child_index++;
            }
        }

    }else{
        for(int i=0; i< root->num_children; i++){ //not leaf so recurse to find leafs 
            expand_tree(root->children[i]);
        }
    }

}

// Count the number of nodes in the tree 
int node_count(TreeNode *root){
    if(root==NULL){
        return 0;
    }

    int node_counter=1; //node itself   

    for(int i=0; i< root->num_children; i++){
        node_counter+=node_count(root->children[i]);
    }
   
    return node_counter; 
}

// Print the tree for debugging purposes (optional)
/* void print_tree(TreeNode *root, int level) {
    if (root == NULL) {
        return;  
    }

    // Print the current game state
        for (int i = 0; i < level; i++) {
        printf("  ");  
    }

    printf("Evaluation: %d\n", root->game_state->evaluation); // prints evaluation score
    
    //print all children 
    for (int i = 0; i < root->num_children; i++) {
        print_tree(root->children[i], level + 1);  // recursive call 
    }
}
 */